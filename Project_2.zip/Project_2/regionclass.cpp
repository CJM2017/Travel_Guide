#include "regionclass.h"
#include "ui_RegionChoice"

regionClass::regionClass(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::regionClass)
{

}
